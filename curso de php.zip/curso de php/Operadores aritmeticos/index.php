
 
 <?php 
 
        /*No php, se colocarmos dois valores inteiros emntre aspas em uma soma, ele retorna o valorinteiro da soma, por exemplo */

        $res = "2" + "2";

        echo "<p>Resultado: $res</p>";

        /*Se dermos um var_dump(), poderemos conferir que o valor da variável é inteiro. */

        var_dump($res);

        /*Isso ocorre porque, diferente das outras linguagens, o php possui um sinal de concatenação diferente, que é o '.', sendo assim, o sinal de adição ficar apenas para realizações de soma */

        $res = "2"."2";

        echo "<p> resultado da concatenação com o ponto: $res</p>";
    

        /*Operadores aritméticos */

        /*
            +: adição
            -: subtração
            *: multiplicação
            /: divisão real
            \: divisão inteira
            %: módulo ou resto da divisão inteira.
            **: exponenciação: potência, foi acrescentado a partir do php versão 5.6

        */
 
 
 ?>