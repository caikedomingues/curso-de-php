

<!DOCTYPE html>
<html lang="pt-br">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale: 1.0">
        <title>Resultado</title>
        <link rel="stylesheet" href="estilo/estilo.css">

    </head>

    <body>

        <header>
            <h1>Resultado</h1>
        </header>

        <section>

            <?php

            /*Nesse arquivo php trabalharemos os valores passados pelo usuário */

            /*Criação da variável que ira conter um array que recebera todos os numeros do formulario. Dentro do array devemos colocar o nome do formulário para passar os valores  */
                $numero = $_GET["numero"] ?? 0;
                
                /*Após criar a variável que ira receber os valores, basta calcular o sucessor e o antecessor */
                $antecessor = $numero - 1;

                $sucessor = $numero + 1;

                /*Impressão dos resultados */
                echo "<h1> Resultado Final </h1>";
                
                echo "<p>O sucessor do valor <strong>$numero</strong> é $sucessor</p>";

                echo "<p> o antecessor do valor <strong>$numero</strong> é $antecessor</p>";
            
            ?>

            <form action="index.html">

                <input type="submit" value="Voltar">
            </form>
        </section>
    </body>

</html>