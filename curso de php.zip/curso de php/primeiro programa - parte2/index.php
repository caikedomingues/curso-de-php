<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXERCICIO 1 - PARTE 2</title>
</head>
<body>
    <h1> Dados do servidor</h1>

    <!--Nesse documento vamos mostrar os dados do nosso servidor através do php-->

    <?php
    
       /*Esse código apresenta as informações do php */
       phpinfo(); 


    
    ?>
</body>
</html>