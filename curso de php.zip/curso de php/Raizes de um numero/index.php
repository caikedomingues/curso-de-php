


<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <title>Calculadora de raiz</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>

    <body>

        <header>
            <h1>Calculadora</h1>
        </header>

        <section>

            <?php

                /*Captura do valor */
                $numero = $_GET['numero'] ?? 0;

            ?>
            <form action="<?php $_SERVER=['PHP_SELF'] ?>" method="get" autocomplete="off">
                <label for="numero">Numero:</label>
                <input type="number" name="numero" id="idnumero">
                <input type="submit" value="Calcular">
            </form>
        </section>

        <section>
            <h2>Resultado</h2>

            <?php
                /*Calculo do valor e impressão do resultado */
                
                /*Função que calcula a raiz quadrada */
                $raiz_quadrada = sqrt($numero);

                /*nessa fórmula o valor do expoente será o resultado da divisão entre 1 e 3 que no caso é 3 */
                $raiz_cubica = $numero **(1/3);

                echo "<p> A raiz quadrada do valor <strong> $numero </strong> é <strong>".number_format($raiz_quadrada, 2, ",",".")."</strong></p>";

                echo "<p> A raiz cúbica do valor <strong> $numero</strong> é <strong>".number_format($raiz_cubica, 2, ",", ".")."</strong></p>";
            ?>
        </section> 
    </body>
</html>

