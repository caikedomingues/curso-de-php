<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv = "X-UA Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario retroalimentado</title>
    <link rel="stylesheet" href="estilo/estilo.css">
</head>
<body>
    <header>
        <h1>Formulários retroalimentados</h1>
    </header>

    <section>

        <?php 

            /*Captura dos valores que serão somados */

            $num1 = $_GET['num1'] ?? 0; //valor padrão caso o usuário não passe informações

            $num2 = $_GET['num2'] ?? 0;//valor padrão caso o usuário não passe informações
        ?>

        <!--Esse comando em php é a forma mais segura de linkar a página nela mesma e realiza a retroalimentação do formulário. Com esse comando o php pega o link do seu arquivo e o coloca como o endereço, para verificar o link, basta inspecionar a sua pasta-->
        <form action="<?php echo $_SERVER['PHP_SELF']?>" method="get">
            <label for="num1">1° Número:</label>

            <!--Como os valores somem ao envia-los, vamos atribuir como valor no input as variáveis que capturam os valores-->
            <input type="number" name="num1" id="idnum1" autocomplete="off" value="<?=$num1?>">

            <label for="num2">2° Número</label>
            <input type="number" name="num2" id="idnum2" autocomplete="off" value="<?=$num2?>">

            <input type="submit" value="Enviar">
        </form>
    </section>

    <section>
        <h1>Resultado da soma </h1>

        <?php

            /*Resultado da soma entre os 2 valores */

            $soma = $num1 + $num2;

            echo "<p>A soma entre $num1 + $num2 é igual a $soma</p>";
        ?>
    </section>
</body>
</html>