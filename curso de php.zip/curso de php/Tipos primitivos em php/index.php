


<?php

    /*Categorias dos tipos primitivos*/
    
    /*
        escalares
        compostos
        especiais
    */

    /*Tipos primitivos escalares (foco do curso) */

    $sobrenome = "Silva"; //Variável String
    $idade = 34; //variável do tipo int ou integer.
    $peso = 85.9; /*variavel do tipo float ou double, a palavra real
    deixou de existir na versão 7.4 do php*/

    $casado = true; // variável do tipo boolean ou bool

    /*Como podemos perceber o valor das variáveis definem o seu tipo, diferente do java ou do python, onde é necessário estabelecer um tipo ao declarar a variavel */

    



?>