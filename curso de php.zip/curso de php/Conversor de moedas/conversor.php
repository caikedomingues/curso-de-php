

<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initila-scale 1.0">
        <title>Conversor de Moedas</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>

    <body>
        <header>
            <h1>Resultado</h1>
        </header>

        <section>

           <?php
           
            $valor = $_GET["valor"];

            $conversao = $valor / 4.99;

            /*O metodo number_format() recebe como parametro o número que será convertido, a quantidade de casas decimais, o separador de decimais e o separador de milhar. */

            echo "<p> o valor informado foi <strong>".number_format($valor,2, ",", ".")."</strong> </p>";

            echo "<p> Você possui <strong>".number_format($conversao,2,",", "."). "</strong> dolares</p>";
           
           ?>

           <form action = "index.html">

                <input type="submit" value="Voltar">

           </form>

        </section>
    </body>
</html>