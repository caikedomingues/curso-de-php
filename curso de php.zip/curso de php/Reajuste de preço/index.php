

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initila-scale 1.0">
        <title>Reajuste</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>

    <body>
        <header>
            <h1>Reajuste de preços</h1>
        </header>

        <section>

            <?php

                $preco = $_GET['preco'] ?? 0;

                $reajuste = $_GET['reajuste'] ?? 0;
            
            ?>

            <form action="<?php $_SERVER=['PHP_SELF'] ?>" method="get">
                <label for="preco">Preço do produto(R$)</label>
                <input type="number" step="0.01" name="preco" id="idpreco" required value="<?=$preco?>">

                <!--Nesse exercicio teremos que usar o javascript para mudar o valor da porcentagem enquanto o usuário muda o range. Pensando nisso, precisamos utilizar uma linguagem que rode na maquina do cliente.-->
                <label for="reajuste">Qual será o percentual de reajuste?(<strong><span id="p"></span></strong>%)</label>

                <input type="range" name="reajuste" id="idreajuste" min="0" max="100" step="1" oninput="mudaValor()">

                <input type="submit" value="Reajustar">
            </form>
        </section>

        <section>
            <h2>Resultado do Reajuste</h2>
            <?php
            
                $porcentagem = ($reajuste * $preco) / 100;
        
                $resultado = $preco + $porcentagem;

                echo "<p> O produto que custava ".number_format($preco,2,",","."). ", com $reajuste% de aumento vai passar a custar ".number_format($resultado,2,",", ".")." reais a partir de agora.</p>"

            ?>
        </section>

        <!--Nessa parte vamos trabalhar o javascript, se não me engano, também é possivel trabalhar o javascript em um outro documento.-->

       
        <script>
            /*Dentro do script vamos criar a função responsável por alterar o valor de forma dinâmica */

            //chamada do método após sua criação
            mudaValor();

            function mudaValor(){

                /*Dentro da função, iremos usar um inner text que recebera como parametro o id do input do range */
                /*Na cahamda do inner text utilizamos o id definido na span.innertext = id do input.value */
                p.innerText = idreajuste.value;
            }
            
            //chamada do método
           
        </script>
    </body>
</html>