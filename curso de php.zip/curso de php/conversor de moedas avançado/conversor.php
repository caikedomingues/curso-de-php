

<!DOCTYPE html>

    <html lang="pt-br">

        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA Compatible" content="IE-edge">
            <meta name="viewport" content="width=device-width, initial-scale 1.0">
            <title>Resultado</title>
            <link rel="stylesheet" href="estilo/estilo.css">
        </head>



        <body>

            <header>
                <h1>Resultado</h1>

            </header>

            <section>

        
                    <?php


                        $valor = $_GET["valor"];
                        /*Antes de começar é necessário atualizar o link e colocar sempre a data atual, no nosso caso precisamos atualizar o dia atual e a data dos 7 dias atrás que foi intervalo escolhido. */
                        $inicio = date("m-d-Y", strtotime("-7 days"));
                        $fim = date("m-d-Y");
                        /*Após realizar todas as configurações no site do banco central do brasil e adquirir o link no formato json, vamos criar uma variável
                        que ira receber como valor o link da cotação do dolar.
                        Observação: o link deve estar entre aspas simples, pois o link contem alguns sifroes($), sendo assim, ao colocar em aspas simples o php não ira interpretar os sifrões. */

                        $url = 'https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/CotacaoDolarPeriodo(dataInicial=@dataInicial,dataFinalCotacao=@dataFinalCotacao)?@dataInicial=\''.$inicio.'\'&@dataFinalCotacao=\''.$fim.'\'&$top=1&$orderby=dataHoraCotacao%20desc&$format=json&$select=cotacaoCompra,dataHoraCotacao';


                        /*Após a preparação da url, precisamos tratar os dados que serão passados pelo link. Como o formato é json, vamos utilizar o metodo json_decode() que serve para tratar dados e trabalha com 2 parametros. */

                        /*O primeiro parametro é o metodo file_get_contents que ira pegar o conteudo do link, o segundo parametro é um valor booleano que no nosso caso será verdadeiro */

                        /*A diferença é que caso o parametro seja verdadeiro ele alocara os dados em um array. Se o parametro for falso ele ira alocar em um objeto */

                        $dados = json_decode(file_get_contents($url), true);

                        /*O próximo passo é dar um var_dump em dados e verificar a posição do valor da cotação */

                        $cotacao = $dados["value"][0] ["cotacaoCompra"];

                        /*Por fim conseguimos pegar o valor da cotação do site do banco central do brasil  */
                        echo "<p> A cotação foi ".number_format($cotacao, 2,",", ".")."</p>";

                        $resultado = $valor / $cotacao;

                        echo "<p> Você possui ".number_format($resultado, 2, ",", ".")." reais </p>";





                    ?>

                   <form action="index.html">

                       <input type="submit" value="voltar">
                  </form>
            </section>

    </body>
    </html>
