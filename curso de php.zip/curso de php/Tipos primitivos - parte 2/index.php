

<!DOCTYPE html>
<!--Código base do html-->
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">

        <title>Tipos primitivos - parte 2</title>
    </head>

    <body>

        <h1>Teste de tipos primitivos</h1>
        <?php

            /*Aqui será os códigos em php */

            $numero = 300; //Variável do tipo inteiro

            /*Impressão do resultado */

            echo "O valor da variável é $numero";

            /*Agora vamos mudar o valor dessa variável e colocar um numero em hexadecimal. Todo numero hexadecimal começa com 0x e o numero hexadecimal. */

            $numero = 0x1A;// aqui temos o valor 26 em hexadecimal

            echo "<p> O valor da variável em hexadecimal é $numero </p>";

            /*Agora a mudança será para binário, onde o valor deve começar com 0b e o valor em binário*/

            $numero = 0b1011; // valor 11 em binário

            echo "<p> O valor em da variável em binário é $numero</p>";

            /*Caso queira escrever um valor em octal, basta adicionar um zero no começo e o valor em octal */

            $numero = 010; //valor 8 em octal

            echo "<p>O valor octal da variável é $numero</p>";

            /*A função var_dump() tem como objetivo mostrar o maximo de informações possiveis da variável como o seu tipo */

            $num = 300;

            var_dump($num); /*Aqui a função ira mostrar o valor e o tipo da variável */

            /*Quando utilizamos 2 valores numéricos com um e no meio, estamos dizendo que o primeiro valor será multiplicado por 10 elevado ao segundo numero:
            por exemplo: 3e2 = 3 x 10(2) = 300 */

            $num = 3e2;

            echo "<p> O valor será igual a $num </p>";

            /*em casos em que trabalhamos com potência o php considera o valor como float */

            var_dump($num);

            /*Nós também podemos forçar o resultado da função colocando uma tipagem na atribuição de valor da variável */

            $num = (int) 3e2;

            var_dump($num);

            /* variáveis compostas: array e object */

            /*Para dar inicio criaremos um vetor/array. Dentro de um array é possivel ter vários tipos de valores*/

            $vet=[6, 2, 9, 3, 5];

            /*Var_dump() no vetor para coletar as informações que no caso será o tipo da variável, a quantidade de espaço que o array possui e seus valores. Também ira apontar o tipo dos valores que estão dentro do array*/

            var_dump($vet);

            /*Tipo object ou objeto */

            echo"<p>--------------Apenas para separar--------------</P>";

            /*Vamos crair um objeto pessoa que tera apenas um atributo privado */


            class pessoa{
                
                /*Variável do tipo string privada */
                private string $nome;
            }

            /*S dermos um var_dump() ele ira apontar que é um objeto, a quantidade de vezes que foi instanciado, o tipo da variável e se ela é publica ou privada e se ja foi ou não inicializada*/

            /*Instanciaçãop do objeto */

            $pessoa = new pessoa;
            var_dump($pessoa);
        ?>
    </body>
</html>