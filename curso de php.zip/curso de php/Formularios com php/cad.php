
<!--Dentro do arquivo php iremos trabalhar com os valores passados pelo usuário na página index.html, para isso, criaremos um código padrão em html e usaremos o css da página index.html-->


<!DOCTYPE html>

<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE=edge">
        <meta name="viewport"content="width=device-width,initial-scale=1.0">

        <title>Resultado</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>

    <body>
        <!--Dentro do body teremos a tag header e a tag main, onde o header conterá o titulo e a main o código php que ira trabalhar os valores recebidos-->

        <header>

             <h1>Resultado do processamento</h1>

        </header>

        <main>

            <?php

                /*No php existe variáveis superglobais que não precisam ser declaradas basta utilza-las, sendo assim, daremos um var_dump() nessa variável para conferir as informações sobre os forms do html*/

                /*Ao executar no navegador, podemos perceber que essa variável é um array que possui uma quantidade de espaços, no caso a quantidade de espaços é definida pela quantidade de elementos do formulário.
                Observação: como o nosso formulário utiliza de métodos get é necessário especificar ele no ato de passar a variável como parametro no método var_dump().
                */

                //var_dump($_GET);

                 /*A super global $_REQUEST é a junção das super globais $_GET, $_POST, $COOKIES */

                /*Agora vamos criar uma variável nome que ira receber um array através da variável global $_GET. O array ira receber como valor o name do input definido no form */

                /*Criação da variável que ira receber os primeiros nomes */

                 /*A partir da versão 7 foi criado um operador de coalescência nula que ira verificar se a variável esta vázia e caso essa afirmação seja verdadeira, o operador irá apresentar uma mensagem padrão*/    
                $nome = $_GET["nome"] ?? "Sem nome";

                /*A variável sobrenome ira sofrer o mesmo processo */

                $sobrenome = $_GET["sobrenome"] ?? "Sem sobrenome";

                /*Agora vamos imprimir uma mensagem utilizando os 2 nomes */

                echo "É um prazer te conhecer $nome $sobrenome ! Este é o meu site";

                       

                
            ?>
            <!--Também é possivel trabalhar com um pouco de javascript. Vamos criar um link para voltar a página anterior-->

            <p>
                <a href="javascript:history.go(-1)">Voltar para a página anterior</a>
            </p>

        </main>
    </body>
</html>