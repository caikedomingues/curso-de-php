

<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <title>Anatomia da divisão</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>

    <body>
        <header>
            <h1>Anatomia de uma divisão</h1>
        </header>

        <?php
        
            /*Captura dos valores  */

            $dividendo = $_GET['dividendo'] ?? 0;
            
            /*Como não há divisão por 0, o divisor recebe como valor padrão 1, caso contrário o código apresentara erro*/
            $divisor = $_GET['divisor'] ?? 1;
        
        ?>

        <section>
            <!--O value ira receber o valor padrão das variaveis dividendo e divisor-->
            
            <!--Para evitar a entrada de numeros negativos, vamos atribuir como valor minimo o 0-->
            <form action = "<?php $_SERVER['PHP_SELF'] ?>" method="get">
                <label for="dividendo">Dividendo: </label>
                <input type="number" name="dividendo" id="iddividendo" autocomplete="off" value="<?=$dividendo?>" min="0">

                <label for="divisor"> Divisor: </label>
                <!--O input do divisor terá como valor minimo 1, já que não existe divisão por 0-->
                <input type="number" name="divisor" id="iddividor" autocomplete="off" value="<?=$divisor?>" min="1">

                <input type="submit"value="Calcular">
            </form>
        </section>

        <section>

                <h1>Resultado</h1>
            <?php

                /*Cálculo das divisões */
                $divisao = $dividendo / $divisor;

                $parte_inteira_divisao = (int) $divisao;

                $resto_da_divisao = $dividendo % $divisor;
            ?>
        </section>

        <!--Agora vamos usar as short tags para imprimir os resultados dentro de uma tabela em html-->
        
        <!--Criação da tabela-->
        <table class="divisao">
            <!--O tr são as linhas-->
            <tr>
                <!--Os tds são table datas e são usados para definir as células-->
                <td><?=$dividendo?></td>
                <td><?=$divisor?></td>
            </tr>

            <tr>
                <td><?=$resto_da_divisao?></td>
                <td><?=$parte_inteira_divisao?></td>
            </tr>
        </table>
    </body>
</html>