


<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content = "IE-edge">
        <meta name="viewport" content="width=device-width, initila-scale 1.0">
    </head>


    <body>

    <?php

        /*Superr globais em php

            $GET
            $POST

            Query String: é uma solicitação, ou seja, a url com parametros
        */

        echo "<h1> Superglobal GET</h1>";
        
        /*Informações da superglobal GET */
        var_dump($_GET);


        echo "<h1> Superglobal POST</h1>";

        var_dump($_POST);





?>
    </body>
</html>