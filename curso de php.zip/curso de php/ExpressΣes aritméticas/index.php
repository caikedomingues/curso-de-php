

<?php

    /*Algumas funções aritméticas */

    /*abs: a função abs retorna o valor absoluto de um numero que basicamente é o mesmo número sem considerar o seu sinal ou também pode ser a distância do valor até na reta numérica.*/

    $res = abs(-300);

    echo "A resposta é $res";

    /*base_convert: serve para converter bases numéricas e trabalha com 3 parametros sendo eles: o valor que vai ser convertido, a base que ele está, a base que ira converter. Sendo assim  254 na base 10 para 8 (octal) temos 376*/

    $res = base_convert(254,10,8);

    echo "<p>o valor 254 na base 10 em octal é: $res</p>";

    /*hypot(): Serve para calcular a hipotenusa de um numero, para isso recebe como parametro os valores dos catetos */
    $res = hypot(2.30,1.30);

    echo "A hipotenusa é: $res";

    /*intdiv(): serve para mostrar o valor inteiro de uma divisão */

    $res = intdiv(5,2);

    echo "<p>valor inteiro da divisão entre 5 e 2 é:  $res</p>";

    /*min(): retorna o valor minimo de um conjunto de valores */

    $res = min(2,4,5,6,7,10);

    echo "<p> O valor minimo dessa sequência é: $res</p>";

    /*max(): serve para retornar o maior valor de um conjunto de valores*/

    $res = max(2,4,5,6,7,10);

    echo "<p>O valor máximo dessa sequência é: $res</p>";


    /*pi(): Retorna o valor de pi, tmabém podemos usar a constante M_PI que o resultado também será o mesmo.*/

    $res = pi();

    echo "<p>O valor de pi é: $res</p>";

    /*pow(): serve para calcular a potência de um numero, onde o primeiro valor é o numero que será elevado e o segundo sera o expoente */
    $res = pow(5,2);

    echo "<p> o valor de 5 elevado ao quadrado é: $res</p>";

    /*sqrt: calcula a raiz quadrada de um numero */

    $res = sqrt(4);

    echo "<p> A raiz quadrada de 4 é igual a: $res </p>";

    /*exemplo para calcular raiz cubica*/
    $res = 27 **(1/3);

    echo $res;


?>