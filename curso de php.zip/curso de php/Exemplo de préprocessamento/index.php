<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exemplo de préprocessamento</title>
</head>
<body>
    <h1>Exemplo de processamento</h1>

    <?php 

    /*Assim como em outras linguagens, o php possui funções, sendo assim, vamos testar a função date que tem como objetivo retornar datas */

    /*No php, para juntar uma palavra com uma função, utilizamos o "." */

    /*Para usar a função é necessário passar o parametro a informação que você quer receber, no nosso caso, vamos pedir o dia, o mes e o ano atual */
    
    /* */
    echo "Hoje é dia ".date("d/m/y");

    /*Na função date o D maiusculo retorna o dia da semana, o M maiusculo mostra o mes por extenso e o y minusculo mostra apenas os 2 ultimos caracteres.*/

    echo "<p>Hoje é dia </>".date("D/M/Y");

    /*Antes de mostrar o horário será necessário utilizar um comando para configurar o horario o nosso servidor e modifica-lo para o padrão brasileiro */
    date_default_timezone_set("America/Sao_Paulo");

    /*Agora que ja mudamos a timezone para o padrão brasileiro, podemos utilizar a função date para mostrar as horas, agora temos o padrão gmt-3*/

    /*Para mostrar as horas basta passar como parametro G: horario: i:minutos: s: segundos */
    echo "<p>Agora são ".date("G:i:s")." horas</p>";

    /*Agora, até entendi, a função date ira préprocessar os as informações de hora e data do sistema. Basicamente, todo o nosso  código é préprocessado*/
    ?>

</body>
</html>