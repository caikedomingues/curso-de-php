
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <title>Caixa Eletrônico</title>
        <link rel="stylesheet" href="estilo/estilo.css">

        <!--Aqui iremos criar um style local, (não é recomendado) apenas para ajeitar as imagens-->

        <style>
            /*Aqui vamos definir que toda imagem de classe "nota" terá altura de 50px e margin de 5px */
            img.nota{

                height: 50px;
                margin: 5px;
            }
        </style>
    </head>

    <body>
        <header>
            <h1>Caixa Eletrônico</h1>
        </header>

        <section>
            <?php
            
                /*Captura do valor */
                $valor = $_GET['valor'] ?? 0;
            ?>
            <form action="<?php $_SERVER = ['PHP_SELF'] ?>" method="get">
                <label for="valor">Informe o valor do saque:</label>
                <input type="number" step="0.01" name="valor" id="idvalor" required value="<?=$valor?>">
                <p>Notas disponiveis: R$100, R$50, R$10 e R$5</p>
                <input type="submit" value="Sacar" >
            </form>
           
        </section>

        <section>

            <h2>Resultado</h2>

            <p>Saque de <?=number_format($valor, 2, ",", ".")?> reais realizado</p>
            <?php

                $tot100 = intdiv($valor, 100);
                $tot50 = intdiv(($valor % 100), 50);
                $tot10 = intdiv(($valor % 50), 10);
                $tot5 = intdiv(($valor % 10), 5);
            
            ?>

            <ul>
                <li><img src="imagens/100-reais.jpg" alt="100 reais" class="nota"> x <?=$tot100?></li>

                <li><img src="imagens/50-reais.jpg" alt="50 reais" class="nota"> x <?=$tot50?></li>

                <li><img src="imagens/10-reais.jpg"alt="10 reais" class="nota"> x <?=$tot10?></li>

                <li><img src="imagens/5-reais.jpg" alt="5 reais" class="nota"> x <?=$tot5?></li>


            </ul>
        </section>
    </body>
</html>