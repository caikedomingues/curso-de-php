

<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <title>Médias</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>

    <body>

        <header>
            <h1>Média simples e ponderada</h1>
        </header>

        <section>

            <?php

                /*Captura de valoress */

                $valor1 = $_GET['valor1'] ?? 0;

                $peso1 = $_GET['peso1'] ?? 1;

                $valor2= $_GET['valor2'] ?? 0;

                $peso2 = $_GET['peso2'] ?? 1;
            ?>

            <!--Como não há divisão por zero, o valor minimo dos inputs de peso é 1-->
            <!--Os required permite que o form bloqueie as respostas caso os campos estejam vázios-->
            <form action="<?php $_SERVER=['PHP_SELF']?>" method="get">
                <label for="valor1" > 1° valor </label>
                <input type="number" step="0.01" name="valor1" id="idvalor1" autocomplete="off" required value="<?=$valor1?>">

                <label for="peso1"> 1° peso </label>
                <input type="number" step="0.01" name="peso1" id="idpeso1" autocomplete="off" required  value="<?=$peso1?>" min="1">

                <label for="valor2" > 2° valor</label>
                <input type="number" step = "0.01" name="valor2" id="idvalor2" autocomplete="off" required value="<?=$valor2?>">

                <label for="peso2">2° Peso</label>
                <input type="number" step="0.01" name="peso2" id="idpeso2" autocomplete="off" required value="<?=$peso2?>" min="1">

                <input type="submit" value="Calcular">
           </form>
        </section>

        <section>
            <h2>Resultado final</h2>

            <?php

                /*Calculo da média simples */
                $media_simples = ($valor1 + $valor2) / 2;

                /*Calculo da média ponderada */
                $media_ponderada = (($peso1 * $valor1) + ($peso2 * $valor2)) / ($peso1 + $peso2);

                echo "<p> analisando os valores $valor1 e $valor2 temos: </p>";
                
                /*Impressão dos valores com o number format */
                echo "<p>media simples: ".number_format($media_simples,1,",", ".");

                echo "<p> media ponderada com pesos $peso1 e $peso2: ".number_format($media_ponderada, 1, ",", ".")."</p>";

            
            ?>
        </section>
    </body>
</html>