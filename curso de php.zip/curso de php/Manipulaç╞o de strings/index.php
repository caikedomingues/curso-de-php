

<?php

        /*Há quatro formatos de strings */

        /*double quoted: utiliza aspas duplas 
          single quoted: utiliza aspas simples

          Essas 2 informações representam situações diferentes, pois com aspas duplas o php interpreta o conteudo  da mensagem do código, já a aspas simples apenas a imprimi sem interpretar por exemplo:
        */
        
        /*Nesse caso ele ira interpretar que a \u é um código de emoticon */
        echo "com aspas duplas: PHP \u{1F418}";

        /*Agora, se usarmos as aspas simples ele ira escrever literalmente o que está escrito sem interpretar */

        echo '<p>com aspas sinples: php \u{1F418}</p>';

        /*Outro exemplo parecido */

        $nome = "Caike";

        echo "<p> Com aspas duplas: Olá $nome \u{1F596} </p>";

        echo 'Com aspas simples: ola $nome \u{1F596}';

        /*Caso você necessite de usar aspas duplas dentro de uma string que é aberta com aspas duplas, é necessário colocar "\" antes de abrir e "\" antes de fechar, caso contrário o código apresentara erros já que o php ira se confundir na hora de fechar as aspas  */

        $nome = "Rodrigo";
        $sobrenome = "Nogueira";

        echo "<p>$nome \"Minotauro\" $sobrenome</p>";

        /*Algumas sequências de escape para aspas duplas
            
        \n: nova linha
        \t: tabulação horizontal
        \\: barra invertida
        \$: sinal de cifrão
        \u{} codepoint unicode
        
        */

         $nome = "Caike";
         $apelido = "Odinson";
         $sobrenome = "Domingues";

         /*Vamos fazer um exemplo com tabulação */

         echo "<p> $nome \t\"$apelido\"\t $sobrenome </p>";

         /*Exemplo com quebra de linha */
         
         /*Nesse caso, como vamos visualizar num doc html, a quebra de linhas funciona de outra maneira, portanto, a quebra não era funcionar   */
         echo "<p>\n $nome \"$apelido\" $sobrenome</p>";


         /*Heredoc: Utiliza várias linhas, por exemplo:  */
        $curso = "PHP";
        $ano = date('Y');

        /*Basicamente tanto a abertura quanto o fechamento é com uma palavra em maiusculo  */
         echo <<< FRASE

                   estou estudando $curso em $ano

            FRASE;

        /*Ja a sintaxe do nowdoc é parecida com a do heredoc, porém a palavra chave na abertura fica entre aspas simples e diferente da heredoc ele não interpreta os caracteres que significam algo na linguagem como unicodes e sifrões */

        echo <<< 'teste'

               <p> estou estudando $curso em $ano</p>
        teste;

         ?>

