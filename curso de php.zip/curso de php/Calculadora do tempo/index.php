

<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <link rel="stylesheet" href="estilo/estilo.css">
        <title>Calculadora do tempo</title>
    </head>

    <body>
        <header>
            <h1>Calculadora do tempo</h1>
        </header>

        <section>

            <?php
            
                $segundos = $_GET['segundos'] ?? 1;
            
            ?>
            <form action="<?php $_SERVER=['PHP_SELF']?>" method="get">
                
                <label for="segundos">Qual o total de segundos?</label>
                <input type="number" step="0.001" name="segundos" id="idsegundo" required value="<?=$segundos?>" min="0">

                <input type="submit" value="Calcular">

            </form>
        </section>

        <section>
            <h2>Resultado</h2>

            <?php

                /*
                
                1 min = 60 seg

                1 hora = 60 min = 60 x 60 = 3600 seg

                1 dia = 24 horas = 24 x 60 min = 1440 min x 60 = 86.400 seg

                1 semana = 7 dias x 24 horas = 168 horas x 60 minutos = 10.080 minutos x 60 = 604.800 seg

                Agora basta realizar as divisões inteiras, onde o resto da conta deverá ser dividida pelos totais de segundos de cada categoria. (não sei se a explicação foi boa).
                
                */
                
                echo "<p> Analisando o valor que você digitou, <strong>".number_format($segundos, 0, ",", ".")." </strong> segundos equivalem a um total de:</p>";

                $res_semana = intdiv($segundos, 604800);
                $res_dia = intdiv(($segundos % 604800), 86400);
                $res_horas = intdiv(($segundos % 86400 ),3600);
                $res_minutos = intdiv(($segundos % 3600), 60);
               
                
                echo "<p>".number_format($res_semana, 0, ",", ".")." semanas</p>";

                echo "<p>".number_format($res_dia,0, ",", ".")." dias</p>";

                echo "<p>".number_format($res_horas, 0, ",", ".")." horas</p>";
                
                echo "<p>".number_format($res_minutos,0,",",".")." minutos</p>";


            ?>
        </section>
    </body>
</html>