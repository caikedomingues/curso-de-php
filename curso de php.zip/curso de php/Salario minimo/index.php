

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>


    <body>

        <header>
            <h1>Salário Minimo</h1>
        </header>

        <?php

            /*Captura do valor do salário */
            $salario = $_GET['salario'] ?? 0;

         ?>

        <section>
            <form action = "<?php $_SERVER=['PHP_SELF']?>" method="get">
                <label for = "salario">Informe o seu salario</label>
                <input type="number" step="0.01" name="salario" id="idsalario" autocomplete="off">
                <p>Considerando o salário minimo de <strong> R$1.380,60</strong></p>
                <input type="submit" value="Calcular">

            </form>
        </section>

        <section>

            <h2>Resultado Final</h2>
            <?php

                /*Cálculo e impressão dos resultados */
                $salario_minimo = 1380.60;
                $divisao =intdiv($salario,$salario_minimo);
                $resto = $salario % $salario_minimo;


                echo "<p>Quem recebe um salario de ".number_format($salario,2,",","."). " ganha $divisao salários minimos + ". number_format($resto, 2, ",", "."). " reais</p>";
            ?>
        </section>
    </body>
</html>