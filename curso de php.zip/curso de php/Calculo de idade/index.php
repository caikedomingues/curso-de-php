


<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <title>Calculo de idade</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>

    <body>
        <header>
            <h1>Calculando sua idade</h1>
        </header>

        <section>

            <?php

                /*Captura do valor */
                $nascimento = $_GET['nascimento'] ?? 0;

                $ano = $_GET['ano'] ?? 0;

                $ano_atual = date("Y");
            ?>
            <form action="<?php $_SERVER=['PHP_SELF']?>" method="get">
                <!--Os required irão blouear a ação do botão caso os campos estejam vazios-->
                <!--O campo de ano de nascimento terá como valor máximo o ano atual do sistema e o minimo como 1900-->
                <label for="nascimento">Em que ano você nasceu</label>
                <input type="number" name="nascimento" id="idnascimento" autocomplete="off" required min="1900" max="<?=$ano_atual?>">

                <label for="ano">quer saber sua idade em que ano? atualmente estamos em <?php echo $ano_atual?></label>

                <input type="number" name="ano" id="idano" autocomplete="off" required value="<?=$ano_atual?>">

                <input type="submit" value="Calcular">
            </form>
        </section>

        <section>
            <h2>Resultado</h2>

            <?php

                /*Cálculo da idade*/
                $idade = $ano - $nascimento;

                echo "</p> em $ano você terá $idade anos de idade</p>"
            ?>
        </section>
    </body>
</html>