

<?php 

    /*Declaração de variáveis */

    $nome = "Caike";
    $sobrenome = "Domingues";

    /*Impressão de uma mensagem */
    echo "Muito prazer, $nome $sobrenome";

    /*Como as variáveis podem ter o seu valor alterado a qualquer momento, vamos trocar o valor da variável nome */

    $nome = "Leandro";

    echo "<p> Muito prazer, $nome $sobrenome </p>";

    /*Agora vamos fazer o mesmo com a outra variável */

    $sobrenome = "Silva";

    echo "Muito prazer $nome $sobrenome";

    /*Agora vamos criar uma constante, que basicamente, carrega valores 
    que não podem ser modificados ou alterados, sendo assim caso você altere uma constante, ela dara erro no código */

    const PAIS = "Brasil";

    /*Como as constantes não possuem "$" não podemos escreve-las dentro das aspas na hora de imprimir uma mensagem. */
    echo "<p>muito prazer $nome $sobrenome você mora no ".PAIS. "</p>";

    /*Criação de uma variável com camelCase que tem como objetivo estabelecr um padrão onde a primeira letra do nome de uma variável seja minuscula e a primeira letra da segunda palavra ou sobrenome seja minusculo, por exemplo */

    $nomeCompletoCliente = "camelCase";

    /*Ja o Snake Case consiste em dividir as palavras e nomes com um underline */

    $telefone_contato_fornecedor = "Snake Case";
?>