



<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset = "utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <title>Reultado</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>

    <body>

              <header>
                <h1>Resultado</h1>
            </header>

            <section>
                <?php

                    /*Aqui iremos trabalhar o gerador. Para isso vamos atribuir a uma variável a função random que ira ter como valor inicial o 0 e o 101 já que o 0 também é considerado na contagem */
                    $gerar = random_int(0, 100);
                    /*Apos a criação do metodo basta imprimi-lo com uma mensagem */
                    echo "<p>O valor gerado foi <strong>$gerar</strong></p> ";

                    /*Há outros tipos de random que podemos utilizar
                    
                    rand: craido em 1951 e significa Linear Congretial Generator, é um algoritmo antigo e lento

                    mt_rand: criado em 1997, é 4x mais rápido que o rand.
                    Significa Mersenne Twister e é um dos geradores atuais e mais confiáveis.

                    random_int(): gera numeros inteiros aleatórios com criptografia segura, ou seja, caso você trabalhe com senhas ou algo assim, essa função é a mais segura para esse tipo de situação. Entretanto, é o  algoritmo mais lento de todos eles.
                    */
                ?>

                 <!--Criação do botão para voltar para a página inicial-->
                <form action="index.html">

                    <input type="submit"  value="Voltar">
                </form>
            </section>
    </body>
</html>

