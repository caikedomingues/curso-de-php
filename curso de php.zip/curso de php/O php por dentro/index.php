<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Exemplo</h1>
    <?php 
    
         /*O php permite a criação de variáveis, porém ele não declara variáveis, apenas as inicializa. */
       $nome = "Caike";
       echo "O meu nome é $nome";

       /*É possivel diminuir a abertura da tag do php utilizando apenas o código <?
            Código php
       ?> conhecido como short open tag*/

       /*É possivel delimitar usando o asp tag que é derivada da linguagem asp desenvolvida pela microsoft 
       
       <%  Código em php %>
       */

       /*A short tag php tem como incializar o php através de um único comando echo, por exemplo se vc for escrever apenas uma palavra ou frase, você pode inicializar da seguinte maneira:
        
        <?= "frase" ?>
        */

        phpinfo();

        /*Através do phpinfo conseguimos verificar qual linha está dando erro no código. */

        /*Como php possui préprocessamento, o phpinfo gera 1000 linhas de códigos html pré estabelecidos que ira gerar uma tabela com as informações do servidor, ou seja, esse pequeno comando tem dentro dele vários códigos dentro dele. */
    
    ?>
</body>
</html>