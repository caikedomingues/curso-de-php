
<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <title> Resultado</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>

    <body>
        <header>
            <h1>Resultado</h1>
        </header>    

        <section>

            <?php
            
            
                $numero = $_GET["valor"];

                /*Após capturar o valor do formulário, basta separar a parte inteira da parte fracionária */

                /*Para isso, vamos criar uma variável para armazenar o valor inteiro */
                $parte_inteira = (int) $numero;

                /*Já a parte fracionária de um numero é badicamente a parte inteira - o numero */
                $parte_fracionaria = $parte_inteira - $numero;

                echo "<p>Analisando o numero <strong>".number_format($numero, 3, ",", ".")."</strong> informado pelo usuário:</p>";

                echo "<p> parte inteira do valor: <strong>$parte_inteira</strong></p>";

                echo "<p> parte fracionária do valor <strong>".number_format($parte_fracionaria, 3, ",", ".")."</strong></p>";

            ?>

            <form action = "index.html">
                
                <input type="submit" value="Voltar">

            </form>
        </section>
    </body>

</html>