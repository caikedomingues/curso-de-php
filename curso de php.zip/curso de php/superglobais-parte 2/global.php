

<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta http-equiv= "X-UA Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <title> Resultados</title>
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>


    <body>

        <header>
            <h1>Resultados</h1>
        </header>

        <section>
        <pre>
            <?php
            
                $usuario = $_POST["usuario"];
                $senha = $_POST["senha"];

                echo "<p>usuario: $usuario</p>";

                echo "<p>senha: $senha</p>";

                /*Agora aqui embaixo, vamos visualizar as informações das superglobais*/

                echo "<p>Informações do GET: ".var_dump($_GET)."</p>";

               echo "<p>Informações do POST: ".var_dump($_POST)."</p>";


               /*permite a configuração da superglobal $_COOKIE  */

                /*Nesse caso ele irase chamar "dia-da-semana", ira receber o valor "segunda" e ira durar 1 hora, ou seja, 3600 segundos */
                setcookie("dia-da-semana", "segunda", time() + 3600);

                /*Agora vamos visualizar as informações */
               echo "<p>Informações da variável COOKIE: ".var_dump($_COOKIE)."</p>";


               /*Informações da variável $_SESSION */

               /*Antes de acessa-la é necessário inicialia-la com um método */
               session_start();

               /*Após a inicialização, podemos cria-la e atribuir um valor a ela. */
               $_SESSION["teste"] = "FUNCIONOU";

               /*Agora, podemos utiliza-la normalmente */

               echo "<p>informações do SESSION: ".var_dump($_SESSION)."</p>";

               /*A superglobal env talvez não funcione em servidores locais, até onde entendi é uma variável de ambiente */

               echo "<p> informações de ambiente: ".var_dump($_ENV)."</p>";


              /*A superglobal server ira mostrar informações do servidor local */

              echo "<h2> Informações do servidor</h2>";

              echo "<p>".var_dump($_SERVER)."</p>";

              /*A GLOBALS tem como função mostrar as informações de todas as variáveis globais */

              echo "<h2> GLOBALS </h2>";

              echo "<p>".var_dump($GLOBALS)."</p>";

                
            ?>
        </pre>
            <form action="index.html">

                <input type="submit" value="Voltar">

            </form>
        <section>
    </body>
</html>