
<!--Primeiro vamos criar o código padrão em html -->

<DOCTYPE html>
    <html lang = "pt-br">
        <head>
            
            <!--O content = ie-edge significa a compatibilidade com o navegador edge-->
            <meta charset = "utf-8">
            <meta http-equiv="X-UA-Compatible" 
            content="IE-edge">
            <!--Viewport significa o tamanho / largura da tela que por padrão é 100%-->
            <meta name = "viewport" content = "width=device-width, initial-scale=1.0">

            <title>Documento</title>
        </head>

        <body>
            
            <!--Dentro do body, vamos criar um h1 que conterá o nosso primeiro script em php-->
            <h1>
              <!--Abertura de uma tag php que também pode ser chamada de super tag-->

              <!--O php não possui case sensitive em alguns comandos como no caso do comando echo-->
              <!--Observação: no lugar de echo também podemos utilizar o comando print-->
              <?php
                    /*O php também é compativel com emoticons, basta digitar
                    \u{código do emoticon}  */
                    echo "Olá, Mundo \u{1F30E}";

                    
              ?>
            </h1>

            <p>Vamos nos livrar da maldição</p>
        </body>
    </html>